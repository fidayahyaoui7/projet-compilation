#include <stdio.h>
#include "lexer.h"
#include "parser.h"
#include "symtab.h"

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Usage: %s source.txt\n", argv[0]);
        return 1;
    }
    init_lexer(argv[1]);
    parse_program();
    close_lexer();
    symtab_print();
    return 0;
}
