#include <stdio.h>
#include <stdlib.h>
#include "tokens.h"
#include "lexer.h"
#include "symtab.h"

static void error(const char *msg) {
    fprintf(stderr, "Syntax error at line %d: %s (found '%s')\n", lineNo, msg, lexeme);
    exit(1);
}

static void match(int expected) {
    if (token == expected) next_token();
    else {
        char buf[128];
        sprintf(buf, "expected token %d", expected);
        error(buf);
    }
}

static void parse_decls();
static void parse_list_id();
static void parse_insts();
static void parse_inst();
static void parse_cond();
static void parse_exp();
static void parse_term();
static void parse_factor();

void parse_program() {
    if (token != TOK_PROGRAM) error("program expected");
    match(TOK_PROGRAM);
    if (token != TOK_ID) error("program name expected");
    symtab_insert(lexeme);
    match(TOK_ID);
    match(TOK_SEMI);
    parse_decls();
    match(TOK_BEGIN);
    parse_insts();
    match(TOK_END);
    match(TOK_DOT);
    printf("Analyse syntaxique OK.\n");
}

static void parse_decls() {
    if (token != TOK_VAR) error("var expected");
    match(TOK_VAR);
    parse_list_id();
    match(TOK_COLON);
    if (token != TOK_INT) error("type 'int' expected");
    match(TOK_INT);
    match(TOK_SEMI);
}

static void parse_list_id() {
    if (token != TOK_ID) error("identifier expected");
    symtab_insert(lexeme);
    match(TOK_ID);
    while (token == TOK_COMMA) {
        match(TOK_COMMA);
        if (token != TOK_ID) error("identifier expected after comma");
        symtab_insert(lexeme);
        match(TOK_ID);
    }
}

static void parse_insts() {
    while (token == TOK_ID || token == TOK_WRITELN || token == TOK_READLN || token == TOK_IF) {
        parse_inst();
    }
}

static void parse_inst() {
    if (token == TOK_ID) {
        if (symtab_find(lexeme) < 0)
            fprintf(stderr, "Warning: use of undeclared id '%s' (line %d)\n", lexeme, lineNo);
        match(TOK_ID);
        match(TOK_AFFECT);
        parse_exp();
        match(TOK_SEMI);
    } else if (token == TOK_WRITELN) {
        match(TOK_WRITELN);
        match(TOK_LPAR);
        if (token != TOK_ID) error("identifier expected in writeln");
        if (symtab_find(lexeme) < 0)
            fprintf(stderr, "Warning: writeln uses undeclared id '%s' (line %d)\n", lexeme, lineNo);
        match(TOK_ID);
        match(TOK_RPAR);
        match(TOK_SEMI);
    } else if (token == TOK_READLN) {
        match(TOK_READLN);
        match(TOK_LPAR);
        if (token != TOK_ID) error("identifier expected in readln");
        if (symtab_find(lexeme) < 0)
            fprintf(stderr, "Warning: readln uses undeclared id '%s' (line %d)\n", lexeme, lineNo);
        match(TOK_ID);
        match(TOK_RPAR);
        match(TOK_SEMI);
    } else if (token == TOK_IF) {
        match(TOK_IF);
        parse_cond();
        match(TOK_THEN);
        parse_insts();
        match(TOK_ENDIF);
    } else {
        error("invalid instruction");
    }
}

static void parse_cond() {
    parse_exp();
    if (token == TOK_OPREL_EQ || token == TOK_OPREL_NE || token == TOK_OPREL_LT ||
        token == TOK_OPREL_LE || token == TOK_OPREL_GT || token == TOK_OPREL_GE) {
        match(token);
    } else error("relational operator expected");
    parse_exp();
}

static void parse_exp() {
    parse_term();
    while (token == TOK_PLUS) {
        match(TOK_PLUS);
        parse_term();
    }
}

static void parse_term() {
    parse_factor();
    while (token == TOK_MULT) {
        match(TOK_MULT);
        parse_factor();
    }
}

static void parse_factor() {
    if (token == TOK_ID) {
        if (symtab_find(lexeme) < 0)
            fprintf(stderr, "Warning: use of undeclared id '%s' (line %d)\n", lexeme, lineNo);
        match(TOK_ID);
    } else if (token == TOK_NB) {
        match(TOK_NB);
    } else if (token == TOK_LPAR) {
        match(TOK_LPAR);
        parse_exp();
        match(TOK_RPAR);
    } else error("factor expected");
}
