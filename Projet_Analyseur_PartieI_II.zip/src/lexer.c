#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "tokens.h"
#include "lexer.h"

static FILE *fin;
static int curChar;
int lineNo = 1;
char lexeme[256];
int token;

static void next_char() {
    curChar = fgetc(fin);
    if (curChar == '\n') lineNo++;
}

void init_lexer(const char *filename) {
    fin = fopen(filename, "r");
    if (!fin) { perror("fopen"); exit(1); }
    curChar = fgetc(fin);
    next_token();
}

void close_lexer() {
    fclose(fin);
}

static void skip_ws_and_comments() {
    while (1) {
        if (curChar == EOF) return;
        if (isspace(curChar)) { next_char(); continue; }
        if (curChar == '(') {
            int c = fgetc(fin);
            if (c == '*') {
                int prev = 0;
                curChar = fgetc(fin);
                while (!(prev == '*' && curChar == ')') && curChar != EOF) {
                    prev = curChar;
                    curChar = fgetc(fin);
                }
                next_char();
                continue;
            } else {
                ungetc(c, fin);
                curChar = '(';
                return;
            }
        }
        break;
    }
}

static int keyword_or_id(const char *s) {
    if (!strcmp(s,"program")) return TOK_PROGRAM;
    if (!strcmp(s,"var")) return TOK_VAR;
    if (!strcmp(s,"Begin")) return TOK_BEGIN;
    if (!strcmp(s,"End")) return TOK_END;
    if (!strcmp(s,"Endif")) return TOK_ENDIF;
    if (!strcmp(s,"then")) return TOK_THEN;
    if (!strcmp(s,"int")) return TOK_INT;
    if (!strcmp(s,"readln")) return TOK_READLN;
    if (!strcmp(s,"writeln")) return TOK_WRITELN;
    if (!strcmp(s,"if")) return TOK_IF;
    return TOK_ID;
}

void next_token() {
    lexeme[0] = '\0';
    skip_ws_and_comments();

    if (curChar == EOF) {
        token = TOK_EOF;
        strcpy(lexeme, "<EOF>");
        return;
    }

    if (curChar == ';') { token = TOK_SEMI; strcpy(lexeme,";"); next_char(); return; }
    if (curChar == ',') { token = TOK_COMMA; strcpy(lexeme,","); next_char(); return; }
    if (curChar == '.') { token = TOK_DOT; strcpy(lexeme,"."); next_char(); return; }
    if (curChar == '(') { token = TOK_LPAR; strcpy(lexeme,"("); next_char(); return; }
    if (curChar == ')') { token = TOK_RPAR; strcpy(lexeme,")"); next_char(); return; }
    if (curChar == '+') { token = TOK_PLUS; strcpy(lexeme,"+"); next_char(); return; }
    if (curChar == '*') { token = TOK_MULT; strcpy(lexeme,"*"); next_char(); return; }

    if (curChar == ':') {
        next_char();
        if (curChar == '=') { token = TOK_AFFECT; strcpy(lexeme,":="); next_char(); }
        else { token = TOK_COLON; strcpy(lexeme, ":"); }
        return;
    }

    if (curChar == '=') {
        int c = fgetc(fin);
        if (c == '=') { token = TOK_OPREL_EQ; strcpy(lexeme,"=="); next_char(); }
        else { ungetc(c, fin); token = TOK_OPREL_EQ; strcpy(lexeme,"="); next_char(); }
        return;
    }

    if (curChar == '<') {
        next_char();
        if (curChar == '=') { token = TOK_OPREL_LE; strcpy(lexeme,"<="); next_char(); }
        else if (curChar == '>') { token = TOK_OPREL_NE; strcpy(lexeme,"<>"); next_char(); }
        else { token = TOK_OPREL_LT; strcpy(lexeme,"<"); }
        return;
    }

    if (curChar == '>') {
        next_char();
        if (curChar == '=') { token = TOK_OPREL_GE; strcpy(lexeme,">="); next_char(); }
        else { token = TOK_OPREL_GT; strcpy(lexeme,">"); }
        return;
    }

    if (isalpha(curChar)) {
        int i = 0;
        while (isalnum(curChar) && i < (int)(sizeof(lexeme)-1)) {
            lexeme[i++] = curChar;
            curChar = fgetc(fin);
        }
        lexeme[i] = '\0';
        token = keyword_or_id(lexeme);
        return;
    }

    if (isdigit(curChar)) {
        int i = 0;
        while (isdigit(curChar) && i < (int)(sizeof(lexeme)-1)) {
            lexeme[i++] = curChar;
            curChar = fgetc(fin);
        }
        lexeme[i] = '\0';
        token = TOK_NB;
        return;
    }

    fprintf(stderr, "Unknown character '%c' at line %d\n", curChar, lineNo);
    exit(1);
}
