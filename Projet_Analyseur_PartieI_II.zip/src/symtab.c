#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symtab.h"

#define SYMTAB_SIZE 1024

static char *symtab[SYMTAB_SIZE];
static int symtab_count = 0;

int symtab_insert(const char *id) {
    for (int i = 0; i < symtab_count; ++i)
        if (strcmp(symtab[i], id) == 0) return i;
    if (symtab_count >= SYMTAB_SIZE) {
        fprintf(stderr, "Symbol table overflow\n");
        exit(1);
    }
    symtab[symtab_count] = strdup(id);
    return symtab_count++;
}

int symtab_find(const char *id) {
    for (int i = 0; i < symtab_count; ++i)
        if (strcmp(symtab[i], id) == 0) return i;
    return -1;
}

void symtab_print() {
    printf("\nTable des symboles (%d entrées):\n", symtab_count);
    for (int i = 0; i < symtab_count; ++i)
        printf("%d: %s\n", i, symtab[i]);
}
