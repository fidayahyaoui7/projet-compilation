#ifndef LEXER_H
#define LEXER_H

extern int token;
extern char lexeme[256];
extern int lineNo;

void init_lexer(const char *filename);
void next_token();
void close_lexer();

#endif
