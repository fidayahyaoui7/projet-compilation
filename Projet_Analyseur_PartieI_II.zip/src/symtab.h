#ifndef SYMTAB_H
#define SYMTAB_H

int symtab_insert(const char *id);
int symtab_find(const char *id);
void symtab_print();

#endif
