#ifndef PARSER_H
#define PARSER_H

void parse_program();

#endif
